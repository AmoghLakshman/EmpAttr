HR Attrition Streamlit Dashboard

How to use:
1. Push these files to a GitHub repository (files at the repo root).
2. Connect the repo to Streamlit Cloud; it will run app.py by default.
3. Upload your dataset via the app or use the sample dataset provided.
4. Use Dashboard tab for insights, Train & Evaluate to train models, and Predict to run predictions and download CSV.